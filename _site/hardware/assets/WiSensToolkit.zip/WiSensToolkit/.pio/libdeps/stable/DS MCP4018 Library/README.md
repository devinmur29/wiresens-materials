# DS_MCP4018_Library
This library is for the Microchip MCP4018 I2C digital potentiometer